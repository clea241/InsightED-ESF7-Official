const express = require('express');
const router = express.Router();
const { Pool } = require('pg');
require('dotenv').config();

// Create a connection pool to the main 'insightEd' database containing the unit1_school_identity table
const poolString = process.env.DATABASE_URL
  ? process.env.DATABASE_URL.replace('insighted_esf7', 'insightEd')
  : `postgresql://${process.env.DB_USER}:${process.env.DB_PASSWORD}@${process.env.DB_HOST}:${process.env.DB_PORT}/insightEd`;

const insightEdPool = new Pool({
  connectionString: poolString,
  ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : false
});

insightEdPool.on('error', (err) => {
  console.error('[Schools DB Pool Error]:', err.message);
});

const { getSchoolIdFromRequest } = require('../../utils/auth');
const db = require('../../db');

// GET school info directly from unit1_school_identity
router.get('/', async (req, res) => {
  try {
    const schoolId = getSchoolIdFromRequest(req) || '199999';

    // 1. First check local ESF7 database for local school definitions (e.g. test school 199999)
    const localRes = await db.query(
      'SELECT * FROM schools WHERE school_id = $1 LIMIT 1',
      [schoolId]
    );

    if (localRes.rows.length > 0) {
      const localRow = localRes.rows[0];
      let offerings = [];

      if (String(schoolId) === '199999') {
        offerings = ['Elementary', 'JHS', 'SHS'];
      } else if (Array.isArray(localRow.curricular_offering)) {
        const rawList = localRow.curricular_offering.map(o => String(o).toLowerCase());
        if (rawList.some(o => o.includes('elem') || o.includes('primary') || o.includes('kinder'))) offerings.push('Elementary');
        if (rawList.some(o => o.includes('jhs') || o.includes('junior') || o.includes('sec') || o.includes('high'))) offerings.push('JHS');
        if (rawList.some(o => o.includes('shs') || o.includes('senior'))) offerings.push('SHS');
        if (rawList.includes('k-12') || rawList.includes('all')) {
          offerings = ['Elementary', 'JHS', 'SHS'];
        }
      }

      if (offerings.length === 0) {
        offerings = ['Elementary', 'JHS', 'SHS'];
      }

      return res.json({
        schoolId: localRow.school_id || '199999',
        schoolName: localRow.school_name || 'TEST K-12 INTEGRATED SCHOOL',
        region: localRow.region || 'REGION VIII',
        division: localRow.division || 'SAMAR (WESTERN SAMAR)',
        district: localRow.district || 'BASEY I',
        schoolYear: localRow.school_year || 'SY 26-27',
        numberOfShifts: String(localRow.number_of_shifts || 1),
        curricularOffering: Array.from(new Set(offerings)),
        certifiedBy: localRow.certified_by || null,
        certifiedSignature: localRow.certified_signature || null,
        certifiedAt: localRow.certified_at || null,
        subjectsConfig: localRow.subjects_config || null
      });
    }

    // 2. Query main unit1_school_identity
    let result = await insightEdPool.query('SELECT * FROM unit1_school_identity WHERE school_id = $1 ORDER BY updated_at DESC LIMIT 1', [schoolId]);

    if (result.rows.length === 0) {
      // Check esf7_database table for historical school submission identity
      const esfMatch = await insightEdPool.query(
        'SELECT DISTINCT school_name, division, region, muncipality as district FROM esf7_database WHERE school_id = $1 OR schoool_id = $1 LIMIT 1',
        [schoolId]
      ).catch(() => ({ rows: [] }));

      if (esfMatch.rows.length > 0) {
        const esf = esfMatch.rows[0];
        const esfSchoolName = esf.school_name || `School ${schoolId}`;
        const esfRegion = esf.region ? (String(esf.region).toUpperCase().startsWith('REGION') ? esf.region : `REGION ${esf.region}`) : 'REGION V';
        const esfDivision = esf.division || 'DIVISION';
        const esfDistrict = esf.district || 'DISTRICT';

        return res.json({
          schoolId: schoolId,
          schoolName: esfSchoolName,
          region: esfRegion,
          division: esfDivision,
          district: esfDistrict,
          schoolYear: "SY 26-27",
          numberOfShifts: "1",
          curricularOffering: ['Elementary', 'JHS', 'SHS'],
          certifiedBy: null,
          certifiedSignature: null,
          certifiedAt: null,
          subjectsConfig: null
        });
      }

      result = await insightEdPool.query('SELECT * FROM unit1_school_identity ORDER BY updated_at DESC LIMIT 1');
    }

    if (result.rows.length === 0) {
      return res.json({
        schoolId: schoolId || '199999',
        schoolName: `School ${schoolId}`,
        region: "REGION V",
        division: "DIVISION",
        district: "DISTRICT",
        schoolYear: "SY 26-27",
        numberOfShifts: "1",
        curricularOffering: ['Elementary', 'JHS', 'SHS'],
        subjectsConfig: null
      });
    }

    const row = result.rows[0];

    // Map curricular offering string to ESF7 UI check arrays
    let offerings = [];
    if (String(schoolId) === '199999') {
      offerings = ['Elementary', 'JHS', 'SHS'];
    } else {
      const dbOffering = (row.curricular_offering || '').toLowerCase();
      if (dbOffering.includes('elementary') || dbOffering.includes('primary') || dbOffering.includes('purely') || dbOffering.includes('kinder')) {
        offerings.push('Elementary');
      }
      if (dbOffering.includes('jhs') || dbOffering.includes('junior') || dbOffering.includes('secondary') || dbOffering.includes('high school')) {
        offerings.push('JHS');
      }
      if (dbOffering.includes('shs') || dbOffering.includes('senior')) {
        offerings.push('SHS');
      }
      if (offerings.length === 0) {
        offerings = ['Elementary', 'JHS', 'SHS'];
      }
    }

    res.json({
      schoolId: row.school_id || schoolId,
      schoolName: String(schoolId) === '199999' ? 'TEST K-12 INTEGRATED SCHOOL' : (row.school_name || ''),
      region: row.region || '',
      division: row.division || '',
      district: row.district || '',
      schoolYear: 'SY 26-27',
      numberOfShifts: "1",
      curricularOffering: Array.from(new Set(offerings)),
      certifiedBy: null,
      certifiedSignature: null,
      certifiedAt: null,
      subjectsConfig: null
    });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/school/draft - Fetch cloud draft for the school
router.get('/draft', async (req, res) => {
  try {
    const schoolId = getSchoolIdFromRequest(req) || '123456';
    const schoolYear = req.query.schoolYear || 'SY 26-27';

    const result = await db.query(
      'SELECT payload, updated_at FROM school_drafts WHERE school_id = $1 AND school_year = $2',
      [schoolId, schoolYear]
    );

    if (result.rows.length === 0) {
      return res.json({ payload: null });
    }

    res.json({
      payload: result.rows[0].payload,
      updatedAt: result.rows[0].updated_at
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/school/draft - Save/overwrite cloud draft for the school
router.put('/draft', async (req, res) => {
  try {
    const schoolId = getSchoolIdFromRequest(req) || '123456';
    const { schoolYear, payload } = req.body;

    if (!payload) {
      return res.status(400).json({ error: 'Missing draft payload' });
    }

    const result = await db.query(
      `INSERT INTO school_drafts (school_id, school_year, payload, updated_at)
       VALUES ($1, $2, $3, NOW())
       ON CONFLICT (school_id, school_year)
       DO UPDATE SET payload = EXCLUDED.payload, updated_at = NOW()
       RETURNING updated_at`,
      [schoolId, schoolYear || 'SY 26-27', JSON.stringify(payload)]
    );

    res.json({
      success: true,
      updatedAt: result.rows[0].updated_at
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/school/draft - Delete cloud draft for the school
router.delete('/draft', async (req, res) => {
  try {
    const schoolId = getSchoolIdFromRequest(req) || '123456';
    const schoolYear = req.query.schoolYear || 'SY 26-27';

    await db.query(
      'DELETE FROM school_drafts WHERE school_id = $1 AND school_year = $2',
      [schoolId, schoolYear]
    );

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/schools/subjects - Save subjects_config for current school
router.put('/subjects', async (req, res) => {
  try {
    const schoolId = getSchoolIdFromRequest(req) || '123456';
    const { subjectsConfig } = req.body;

    if (!subjectsConfig) {
      return res.status(400).json({ error: 'Missing subjectsConfig' });
    }

    await db.query(
      `INSERT INTO schools (id, school_id, school_name, region, division, school_year, subjects_config)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       ON CONFLICT (school_id, school_year) DO UPDATE
       SET subjects_config = EXCLUDED.subjects_config, updated_at = NOW()`,
      [`SCH-${schoolId}`, schoolId, 'School', 'Region', 'Division', 'SY 26-27', JSON.stringify(subjectsConfig)]
    );

    res.json({ success: true, subjectsConfig });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/schools/curricular-config - Save special_programs and shs_curriculum_model
router.put('/curricular-config', async (req, res) => {
  try {
    const schoolId = getSchoolIdFromRequest(req) || '123456';
    const { hasSpecialPrograms, specialPrograms, shsCurriculumModel, schoolYear } = req.body;

    await db.query(
      `INSERT INTO schools (id, school_id, school_name, region, division, school_year, special_programs, shs_curriculum_model)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       ON CONFLICT (school_id, school_year) DO UPDATE
       SET special_programs = EXCLUDED.special_programs,
           shs_curriculum_model = EXCLUDED.shs_curriculum_model,
           updated_at = NOW()`,
      [
        `SCH-${schoolId}`, 
        schoolId, 
        'School', 
        'Region', 
        'Division', 
        schoolYear || 'SY 26-27', 
        JSON.stringify(specialPrograms || []), 
        shsCurriculumModel || null
      ]
    );

    res.json({ success: true, hasSpecialPrograms, specialPrograms, shsCurriculumModel });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Read-only block: PUT/edit is not allowed
router.put('/', (req, res) => {
  res.status(403).json({ error: "Editing school profile is not allowed in the ESF7 Personnel Portal. This section is read-only." });
});

module.exports = router;
